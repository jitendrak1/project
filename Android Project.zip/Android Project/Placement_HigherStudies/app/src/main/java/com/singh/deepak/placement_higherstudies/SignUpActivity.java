package com.singh.deepak.placement_higherstudies;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
public class SignUpActivity extends AppCompatActivity implements View.OnClickListener {
    EditText signup_input_name, signup_input_rollno,signup_input_password,signup_input_con_password;
    Button btn_signup_create_ac;
    AlertDialog.Builder builder;
    String name, rollno, password;



    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        signup_input_name = (EditText) findViewById(R.id.input_name);
        signup_input_rollno = (EditText) findViewById(R.id.input_rollno);
        signup_input_password = (EditText) findViewById(R.id.input_password);
        signup_input_con_password = (EditText) findViewById(R.id.input_cpassword);
        btn_signup_create_ac = (Button) findViewById(R.id.btn_signup);


        btn_signup_create_ac.setOnClickListener(this);
    }
    @Override
    public void onClick(View v)
    {
        if(signup_input_name.getText().toString().equals("") || signup_input_rollno.getText().toString().equals("") || signup_input_password.getText().toString().equals("") || signup_input_con_password.getText().toString().equals(""))
        {
            builder = new AlertDialog.Builder(this);
            builder.setTitle("Somthing went wrong");
            builder.setMessage("Please fill all the fields....");
            builder.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
            AlertDialog alertDialog = builder.create();
            alertDialog.show();
        }
        else if (!(signup_input_password.getText().toString().equals(signup_input_con_password.getText().toString())))
        {
            builder = new AlertDialog.Builder(SignUpActivity.this);
            builder.setTitle("Somthing went wrong");
            builder.setMessage("Password and Confirm Password is not matched ....");
            builder.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                    signup_input_password.setText("");
                    signup_input_con_password.setText("");
                }
            });
            AlertDialog alertDialog = builder.create();
            alertDialog.show();
        }
        else
        {
            name = signup_input_name.getText().toString();
            rollno = signup_input_rollno.getText().toString();
            password = signup_input_password.getText().toString();
            BackgroundTask backgroundTask = new BackgroundTask(this);
            backgroundTask.execute("register",name,rollno,password);

        }
    }



}
