package com.singh.deepak.placement_higherstudies;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    EditText signup_input_email,signup_input_password;
    TextView textView;
    Button btn_signup_create_ac;
    AlertDialog.Builder builder;
    String email,password;
    public static final String PREFS_NAME = "MyPrefsFile";
    public static final String Email = "emailKey";
    SharedPreferences sharedpreferences;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        sharedpreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        textView = (TextView) findViewById(R.id.link_signup);
        signup_input_email = (EditText) findViewById(R.id.input_email);
        signup_input_password = (EditText) findViewById(R.id.input_password);
        btn_signup_create_ac = (Button) findViewById(R.id.btn_login);
        textView.setOnClickListener(this);
        btn_signup_create_ac.setOnClickListener(this);
    }
    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id)
        {
            case R.id.link_signup:
                Intent signUp = new Intent(LoginActivity.this, SignUpActivity.class);
                startActivity(signUp);
                break;
            case R.id.btn_login:
                loginProcess();
                break;

        }

    }
    public void loginProcess()
    {
        if(signup_input_email.getText().toString().equals("") || signup_input_password.getText().toString().equals(""))
        {
            builder = new AlertDialog.Builder(LoginActivity.this);
            builder.setTitle("Somthing went wrong");
            builder.setMessage("Please fill all the fields....");
            builder.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
            AlertDialog alertDialog = builder.create();
            alertDialog.show();
        }
        else
        {
            SharedPreferences.Editor editor = sharedpreferences.edit();
            email = signup_input_email.getText().toString();
            password = signup_input_password.getText().toString();
            editor.putString(Email, email);
            editor.putBoolean("status", true);
            editor.commit();
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            String email_id = prefs.getString("emailKey", null);
            Log.e("rollNo:",email_id);
            BackgroundTask backgroundTask = new BackgroundTask(this);
            backgroundTask.execute("login", email, password);

        }
    }
}

