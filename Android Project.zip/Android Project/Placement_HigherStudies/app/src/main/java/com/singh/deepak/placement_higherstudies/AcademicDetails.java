package com.singh.deepak.placement_higherstudies;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class AcademicDetails extends AppCompatActivity implements View.OnClickListener {

    AlertDialog.Builder builder;
    EditText editText_year, editText_contact, editText_email;
    Button registration_btn;
    String rollno;
    public static final String PREFS_NAME = "MyPrefsFile";
    long s;
    Spinner department, teacher, course, placement_type;
    ArrayAdapter<CharSequence> adapter, adapter_course, adapter_status;
    String department_name, teacher_name, course_name, placement, year, contact, email_id;

    ArrayAdapter<CharSequence> arrayAdapter;
    String[] teacher_id = {" ", "T101CS", "T102CS", "T103CS", "T104CS", "T105CS", "T106CS", "T107CS", "T108CS", "T109CS", "T110", "T111CS", "T112CS", "T113CS", "T114CS", "T115CS", "T116CS", "T117CS", "T118CS", "T119CS", "T120CS", "T121CS", "T122CS", "T123CS"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_academic_details);
        department = (Spinner) findViewById(R.id.input_department);
        teacher = (Spinner) findViewById(R.id.input_teacher);
        course = (Spinner) findViewById(R.id.input_course);
        placement_type = (Spinner) findViewById(R.id.input_status);
        editText_year = (EditText) findViewById(R.id.input_passing_year);
        editText_contact = (EditText) findViewById(R.id.input_contact);
        editText_email = (EditText) findViewById(R.id.input_email);
        registration_btn = (Button) findViewById(R.id.btn_academic_details);

        adapter = ArrayAdapter.createFromResource(this,
                R.array.department, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        department.setAdapter(adapter);
        arrayAdapter = ArrayAdapter.createFromResource(this, R.array.faculty, android.R.layout.simple_spinner_item);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        teacher.setAdapter(arrayAdapter);
        adapter_course = ArrayAdapter.createFromResource(this, R.array.course, android.R.layout.simple_spinner_item);
        adapter_course.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        course.setAdapter(adapter_course);
        adapter_status = ArrayAdapter.createFromResource(this, R.array.placement_type, android.R.layout.simple_spinner_item);
        adapter_status.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        placement_type.setAdapter(adapter_status);


        department.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                department_name = parent.getItemAtPosition(position).toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        teacher.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                 teacher_name = parent.getItemAtPosition(position).toString();
                getId(id);
               // Log.e("teacher_name :", teacher_name);
                Toast.makeText(AcademicDetails.this, parent.getItemIdAtPosition(position) + "selected", Toast.LENGTH_LONG).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        course.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                course_name = parent.getItemAtPosition(position).toString();
               // Log.e("course :", course_name);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        placement_type.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                placement = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        registration_btn.setOnClickListener(this);
    }

    public void getId(long id) {
        for (int i = 1; i <= teacher_id.length; i++) {
            if (id == i) {
                teacher_name = teacher_id[i];
            }
        }
       // Log.e("name:",teacher_name);
    }


    public void onClick(View view) {

        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String rollno = prefs.getString("emailKey", null);
        year = editText_year.getText().toString();
        contact = editText_contact.getText().toString();
        email_id = editText_email.getText().toString();
        Log.e("department:",department_name);
        Log.e("teacher name:",teacher_name);
        Log.e("cpurse:",course_name);
        Log.e("year:",year);
        Log.e("contact:",contact);
        Log.e("email id:",email_id);
        Log.e("placement:", placement);
        Log.e("rollno Academic:", rollno);


        if (department.equals("Select Department") || teacher_name.equals("Select Faculty Advisor") || course_name.equals("Select Course") || editText_year.getText().toString().equals("") || editText_contact.getText().toString().equals("") || editText_email.getText().toString().equals("") || placement_type.equals("Select Status")) {
            builder = new AlertDialog.Builder(this);
            builder.setTitle("Somthing went wrong");
            builder.setMessage("Please fill all the fields....");
            builder.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
            AlertDialog alertDialog = builder.create();
            alertDialog.show();
        }
        else {
            BackSpinner backSpinner = new BackSpinner(this);
            backSpinner.execute("register",rollno,department_name, teacher_name, course_name, year, contact, email_id, placement);

        }

    }
}






