package com.singh.deepak.placement_higherstudies;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class HigherStudyDetails extends AppCompatActivity implements View.OnClickListener{
    EditText input_ins_name, input_inst_course,input_ins_country,input_int_city;
    Button btn_signup_create_ac;
    AlertDialog.Builder builder;
    String ins_name, rollno,ins_course,ins_country,ins_city;
    public static final String PREFS_NAME = "MyPrefsFile";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_higher_study_details);
        input_ins_name = (EditText) findViewById(R.id.input_insname);
        input_inst_course = (EditText) findViewById(R.id.input_ins_course);
        input_ins_country = (EditText)findViewById(R.id.input_ins_country);
        input_int_city = (EditText)findViewById(R.id.input_ins_city);

        btn_signup_create_ac = (Button) findViewById(R.id.btn_ins_details);
        btn_signup_create_ac.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(input_ins_name.getText().toString().equals("") || input_inst_course.getText().toString().equals("") ||  input_ins_country.getText().toString().equals("") ||  input_int_city.getText().toString().equals(""))
        {
            builder = new AlertDialog.Builder(this);
            builder.setTitle("Somthing went wrong");
            builder.setMessage("Please fill all the fields....");
            builder.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
            AlertDialog alertDialog = builder.create();
            alertDialog.show();
        }
        else
        {
            ins_name = input_ins_name.getText().toString();
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            rollno = prefs.getString("emailKey", null);
            ins_course = input_inst_course.getText().toString();
            ins_country = input_ins_country.getText().toString();
            ins_city = input_int_city.getText().toString();
            BackPlacementDetails backgroundTask = new BackPlacementDetails(this);
            backgroundTask.execute("register",ins_name,rollno,ins_course,ins_country,ins_city);
        }
    }
}
