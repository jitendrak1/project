package com.example.jampassword.nitc_tnp;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class UnplacedActivity extends Activity {

    TableLayout table;
    TextView textView;
    JSONArray jsonArray;
    ArrayList<HashMap<String, String>> arrayList = new ArrayList<HashMap<String, String>>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.unplaced_activity);
        table = (TableLayout) findViewById(R.id.table);
        textView = (TextView) findViewById(R.id.textView);
        new BackgroundWork().execute();
    }

    public class BackgroundWork extends AsyncTask<String, Void, String> {

        @Override
        protected void onPostExecute(String result) {
            for(int i=0;i<=arrayList.size();i++){
                TableRow row = new TableRow(UnplacedActivity.this);
                row.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
                for (int j = 1; j <= 4; j++) {
                    TextView tv = new TextView(UnplacedActivity.this);
                    tv.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT));
                    tv.setPadding(20,20,20,20);
                    if(i==0){
                        if(j==1)
                            tv.setText(Html.fromHtml("<b><u>Name</u></b>"));
                        else if(j==2)
                            tv.setText(Html.fromHtml("<b><u>Roll No</u></b>"));
                        else if(j==3)
                            tv.setText(Html.fromHtml("&nbsp;<b><u>Department</u></b>"));
                        else
                            tv.setText(Html.fromHtml("&nbsp;<b><u>Year</u></b>"));
                    }
                    else {
                        if(j==1)
                            tv.setText(arrayList.get(i - 1).get("name"));
                        else if(j==2)
                            tv.setText(arrayList.get(i - 1).get("rollno"));
                        else if(j==3)
                            tv.setText(arrayList.get(i - 1).get("department"));
                        else
                            tv.setText(arrayList.get(i - 1).get("year"));

                    }
                    row.addView(tv);
                }
                table.addView(row);
            }
        }

        @Override
        protected String doInBackground(String... params) {
            String due_url = "http://andromeda.nitc.ac.in/~m130521ca/ADBMS/unplaced_student.php";
            Log.e("URL", due_url);
            JSONParser jsonParser = new JSONParser();
            JSONObject js = jsonParser.makeHttpRequest(due_url, "GET");
            try {
                jsonArray = js.getJSONArray("server_response");
                Log.e("server_response", "" + jsonArray);

                //take data from JASON
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    String name = jsonObject.get("name").toString();
                    String rollno = jsonObject.get("rollno").toString();
                    String department = jsonObject.get("department").toString();
                    String year = jsonObject.get("year").toString();

                    //fill data into table
                    HashMap<String, String> singleEntry = new HashMap<String, String>();
                    singleEntry.put("name", name);
                    singleEntry.put("rollno", rollno);
                    singleEntry.put("department", department);
                    singleEntry.put("year", year);
                    arrayList.add(singleEntry);
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }
    }
}
