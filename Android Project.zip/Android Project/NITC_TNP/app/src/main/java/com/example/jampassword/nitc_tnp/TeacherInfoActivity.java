package com.example.jampassword.nitc_tnp;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class TeacherInfoActivity extends Activity implements View.OnClickListener{
    AlertDialog.Builder builder;
    TextView teacher_id;
    EditText et_name, et_course, et_year, et_dept, et_contact, et_email, et_pass;
    Button btn_update, btn_reset, btn_cancel;
    String id,name,course,year,dept,contact,email,pass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.teacher_info_activity);
        teacher_id = (TextView)findViewById(R.id.tv_teacher_id);
        et_name = (EditText)findViewById(R.id.et_teacher_name);
        et_course = (EditText)findViewById(R.id.et_teacher_course);
        et_year = (EditText)findViewById(R.id.et_teacher_year);
        et_dept = (EditText)findViewById(R.id.et_teacher_dept);
        et_contact = (EditText)findViewById(R.id.et_teacher_mobile);
        et_email = (EditText)findViewById(R.id.et_teacher_email);
        et_pass = (EditText)findViewById(R.id.et_teacher_password);


        btn_update = (Button)findViewById(R.id.btn_teacher_edit_info);
        btn_reset = (Button)findViewById(R.id.btn_teacher_reset_info);
        btn_cancel = (Button)findViewById(R.id.btn_teacher_cancel_info);

        //fatch Teacher ID from teacher login
        String teacherID =getIntent().getExtras().getString("teacherID");
        teacher_id.setText(teacherID);
        btn_update.setOnClickListener(this);
        btn_reset.setOnClickListener(this);
        btn_cancel.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

   int id = v.getId();
        switch (id)
        {
            case R.id.btn_teacher_edit_info:
                    updateInfo();
                break;

            case R.id.btn_teacher_reset_info:
                resetInfo();
                break;

            case R.id.btn_teacher_cancel_info:
                finish();
                break;
        }

    }

    private void resetInfo() {
            et_name.setText("");
            et_course.setText("");
            et_year.setText("");
            et_dept.setText("");
            et_contact.setText("");
            et_email.setText("");
            et_pass.setText("");
    }

    private void updateInfo() {
            id = teacher_id.getText().toString();
            name = et_name.getText().toString();
            course = et_course.getText().toString();
            year = et_year.getText().toString();
            dept = et_dept.getText().toString();
            contact = et_contact.getText().toString();
            email = et_email.getText().toString();
            pass = et_pass.getText().toString();

        //check empty all control
        if(name.equals("") || course.equals("") || year.equals("") || dept.equals("") || contact.equals("") || email.equals("") || pass.equals(""))
        {
            builder = new AlertDialog.Builder(this);
            builder.setTitle("Somthing went wrong");
            builder.setMessage("Please fill all the fields....");
            builder.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
            AlertDialog alertDialog = builder.create();
            alertDialog.show();
        }
        else{
            //Toast.makeText(getApplication(), "Update Information", Toast.LENGTH_SHORT).show();
            BackSpinner backSpinner = new BackSpinner(this);
            backSpinner.execute(id, name, dept, course, year, contact, email, pass);
        }
    }
}
