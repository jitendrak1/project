package com.example.jampassword.nitc_tnp;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class TeacherLoginActivity extends AppCompatActivity implements View.OnClickListener{

    EditText et_teacher_id, et_teacher_pass;
    Button btn_login;
    AlertDialog.Builder builder;
    String teacher_id,teacher_password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);
        et_teacher_id = (EditText)findViewById(R.id.et_teacher_login);
        et_teacher_pass = (EditText)findViewById(R.id.et_teacher_password);
        btn_login = (Button)findViewById(R.id.btn_teacher_login);

        //Teacher Login into app
        btn_login.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        if(et_teacher_id.getText().toString().equals("") || et_teacher_pass.getText().toString().equals(""))
        {
            builder = new AlertDialog.Builder(TeacherLoginActivity.this);
            builder.setTitle("Somthing went wrong");
            builder.setMessage("Please fill all the fields....");
            builder.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
            AlertDialog alertDialog = builder.create();
            alertDialog.show();
        }
        else
        {
            teacher_id = et_teacher_id.getText().toString();
            teacher_password = et_teacher_pass.getText().toString();
            BackgroundTask backgroundTask = new BackgroundTask(this);
            backgroundTask.execute("login", teacher_id, teacher_password);

            et_teacher_id.setText("");
            et_teacher_pass.setText("");
        }
    }
}
