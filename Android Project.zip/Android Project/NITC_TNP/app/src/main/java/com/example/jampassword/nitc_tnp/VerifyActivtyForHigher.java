package com.example.jampassword.nitc_tnp;

import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class VerifyActivtyForHigher extends AppCompatActivity {

    String text;
    String teacherID;
    TableLayout table;
    TextView textView;
    JSONArray jsonArray;
    ArrayList<HashMap<String, String>> arrayList = new ArrayList<HashMap<String, String>>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.verify_activity);
        table = (TableLayout) findViewById(R.id.table);
        textView = (TextView) findViewById(R.id.textView);

        //fatch teacherID from teacher login
        teacherID = getIntent().getExtras().getString("teacherID");
        new BackgroundWork().execute(teacherID);
    }

    public class BackgroundWork extends AsyncTask<String, Void, String> {

        String username;
        @Override
        protected String doInBackground(String... params) {
            username = params[0];
            String show2_url = "http://andromeda.nitc.ac.in/~m130521ca/ADBMS/verify_study.php?teacher_id="+username;
            JSONParser jsonParser = new JSONParser();
            JSONObject js = jsonParser.makeHttpRequest(show2_url, "GET");

            Log.e("Teacher ID :", username);

            try {
                jsonArray = js.getJSONArray("server_response");
                for (int i = 0; i < jsonArray.length(); i++) {

                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    String name = jsonObject.get("name").toString();
                    String rollno = jsonObject.get("rollno").toString();
                    String department = jsonObject.get("department").toString();
                    String course = jsonObject.get("course").toString();
                    String contact = jsonObject.get("contact").toString();
                    String email = jsonObject.get("email").toString();
                    String year = jsonObject.get("year").toString();
                    String teacher_id = jsonObject.get("teacher_id").toString();
                    String c_name = jsonObject.get("inst_name").toString();
                    String ctc = jsonObject.get("inst_course").toString();
                    String cont = jsonObject.get("country").toString();
                    String city = jsonObject.get("city").toString();

                    HashMap<String, String> singleEntry = new HashMap<String, String>();
                    singleEntry.put("name", name);
                    singleEntry.put("rollno", rollno);
                    singleEntry.put("department", department);
                    singleEntry.put("course", course);
                    singleEntry.put("contact", contact);
                    singleEntry.put("email", email);
                    singleEntry.put("year", year);
                    singleEntry.put("teacher_id", teacher_id);
                    singleEntry.put("c_name", c_name);
                    singleEntry.put("ctc", ctc);
                    singleEntry.put("cont",cont);
                    singleEntry.put("city",city);

                    arrayList.add(singleEntry);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            for(int  i=0;i<=arrayList.size();i++){
                final TableRow row = new TableRow(VerifyActivtyForHigher.this);
                Button accept = new Button(VerifyActivtyForHigher.this);
                accept.setText("accept");
                Button reject = new Button(VerifyActivtyForHigher.this);
                reject.setText("reject");

                row.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
                for (int j = 1; j <= 12; j++) {
                    TextView tv = new TextView(VerifyActivtyForHigher.this);
                    tv.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT));
                    tv.setPadding(20, 20, 20, 20);
                    if(i==0){
                        if(j==1)
                            tv.setText(Html.fromHtml("<b>Name</b>"));
                        else if(j==2)
                            tv.setText(Html.fromHtml("<b>Roll No</b>"));
                        else if(j==3)
                            tv.setText(Html.fromHtml("<b>Department</b>"));
                        else if(j==4)
                            tv.setText(Html.fromHtml("<b>Course</b>"));
                        else if(j==5)
                            tv.setText(Html.fromHtml("<b>Contact</b>"));
                        else if(j==6)
                            tv.setText(Html.fromHtml("<b>Email</b>"));
                        else if(j==7)
                            tv.setText(Html.fromHtml("<b>Year</b>"));
                        else if(j==8)
                            tv.setText(Html.fromHtml("<b>Teacher ID</b>"));
                        else if(j==9)
                            tv.setText(Html.fromHtml("<b>Institute Name</b>"));
                        else if (j==10)
                            tv.setText(Html.fromHtml("<b>Course</b>"));
                        else if (j==11)
                            tv.setText(Html.fromHtml("<b>Country</b>"));
                        else
                            tv.setText(Html.fromHtml("<b>City</b>"));


                    }
                    else {
                        if(j==1)
                            tv.setText(arrayList.get(i - 1).get("name"));
                        else if(j==2)
                            tv.setText(arrayList.get(i - 1).get("rollno"));
                        else if(j==3)
                            tv.setText(arrayList.get(i - 1).get("department"));
                        else if(j==4)
                            tv.setText(arrayList.get(i - 1).get("course"));
                        else if(j==5)
                            tv.setText(arrayList.get(i - 1).get("contact"));
                        else if(j==6)
                            tv.setText(arrayList.get(i - 1).get("email"));
                        else if(j==7)
                            tv.setText(arrayList.get(i - 1).get("year"));
                        else if(j==8)
                            tv.setText(arrayList.get(i - 1).get("teacher_id"));
                        else if(j==9)
                            tv.setText(arrayList.get(i - 1).get("c_name"));
                        else if(j==10)
                            tv.setText(arrayList.get(i - 1).get("ctc"));
                        else if(j==11)
                            tv.setText(arrayList.get(i - 1).get("cont"));
                        else
                            tv.setText(arrayList.get(i - 1).get("city"));
                    }
                    row.addView(tv);
                }
                row.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        TextView textview = (TextView)row.getChildAt(1);
                        text = textview.getText().toString();
                        if (!text.equals("Roll No")) {
                            AlertDialog.Builder builder = new AlertDialog.Builder(VerifyActivtyForHigher.this);
                            builder.setMessage("Do you want to accept/reject : " + text + " ?");
                            builder.setTitle("Student Verification");
                            builder.setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            });

                            // User clicked Accept button
                            builder.setPositiveButton("Accept", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {

                                    AcceptReject accept = new AcceptReject(VerifyActivtyForHigher.this);
                                    accept.execute("accept", text);
                                }
                            });


                            // User Reject button
                            builder.setNegativeButton("Reject", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {

                                    AcceptReject reject = new AcceptReject(VerifyActivtyForHigher.this);
                                    reject.execute("reject", text);
                                }
                            });

                            AlertDialog dialog = builder.create();
                            dialog.show();
                            Log.e("Roll-no", text);
                        }
                        return false;
                    }
                });


                table.addView(row);
            }
        }
    }

}
